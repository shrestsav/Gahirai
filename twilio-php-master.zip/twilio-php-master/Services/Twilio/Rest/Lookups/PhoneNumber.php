<?php

class Services_Twilio_Rest_Lookups_PhoneNumber extends Services_Twilio_LookupsInstanceResource { }
