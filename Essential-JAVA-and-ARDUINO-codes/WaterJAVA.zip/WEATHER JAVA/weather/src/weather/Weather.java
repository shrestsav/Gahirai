package weather;

public class Weather{

    public static void main(String[] args) {
        face myface = new face();
        myface.setVisible(true);
        myface.startInterfacing();
       }
    
}
